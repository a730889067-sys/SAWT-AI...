plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sawt.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sawt.ai"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.0"
        ndk {
            abiFilters += setOf("arm64-v8a", "armeabi-v7a")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    androidResources {
        noCompress += setOf("onnx", "bin")
    }
}

dependencies {
    // Downloaded and SHA-256 checked by scripts/prepare_models.sh.
    implementation(files("libs/sherpa-onnx.aar"))
}
