# إشعارات التراخيص والأطراف الخارجية

يحتوي APK الناتج عن هذا المشروع على محرك ونماذج صوت محلية. تُنزّل هذه الملفات أثناء بناء APK عبر GitHub Actions وتُضمّن داخل التطبيق.

1. **Sherpa-ONNX 1.13.8** — Apache License 2.0. صفحة المشروع: https://github.com/k2-fsa/sherpa-onnx
2. **Kareem Arabic Piper voice (ar_JO, medium)** — ملف الصوت وارد ضمن `rhasspy/piper-voices` الذي يعلن ترخيص MIT: https://huggingface.co/rhasspy/piper-voices. لكن بطاقة نموذج كريم تشير إلى مجموعة تدريب خارجية وتقول إن ترخيصها يُراجع في مصدرها؛ لذلك لا تفترض أن ترخيص مستودع Piper يحسم حقوق مجموعة التدريب: https://github.com/AliMokhammad/arabicttstrain/
3. **Nabra-82M Arabic MSA voice (af_msa)** — Apache-2.0 وفق بطاقة النموذج: https://huggingface.co/marwanelamami/nabra-82m-sherpa-onnx
4. **eSpeak NG data** — بيانات النطق المطلوبة لتوليد الفونيمات العربية. المصدر: https://github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models ؛ راجع ترخيص eSpeak NG في المستودع الأصلي: https://github.com/espeak-ng/espeak-ng
5. **ONNX Runtime** — جزء من إصدار Sherpa-ONNX static-linked؛ راجع إشعارات ترخيص المشروع: https://github.com/microsoft/onnxruntime

يرجى الاحتفاظ بهذا الملف مع أي نسخة تعيد توزيعها. هذا الإشعار ليس استشارة قانونية، ولا يعني أن جميع حقوق بيانات التدريب أو عناصر التطبيق حُسمت. راجع تراخيص المصادر الأصلية قبل التوزيع التجاري.
