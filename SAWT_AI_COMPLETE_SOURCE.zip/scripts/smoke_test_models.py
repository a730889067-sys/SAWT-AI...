#!/usr/bin/env python3
"""Run real Arabic TTS inference against both downloaded models on Linux CI.

This validates model files, model configuration, tokenizer/eSpeak resources, and
Sherpa-ONNX CPU inference before the Android APK is built. It does not replace
an Android-device playback test.
"""
from __future__ import annotations

import gc
import math
import sys
from pathlib import Path

import sherpa_onnx


def verify_audio(label: str, tts: sherpa_onnx.OfflineTts, sample_rate_expected: int) -> None:
    audio = tts.generate(
        "السلام عليكم، هذا اختبار صوت عربي في تطبيق صوت.", sid=0, speed=1.0
    )
    samples = audio.samples
    sample_rate = int(audio.sample_rate)
    if sample_rate != sample_rate_expected:
        raise RuntimeError(
            f"{label}: expected {sample_rate_expected} Hz, got {sample_rate} Hz"
        )
    if len(samples) < sample_rate // 5:
        raise RuntimeError(f"{label}: generated audio is unexpectedly short ({len(samples)} samples)")

    # Check a bounded sample for NaN/Inf without importing NumPy explicitly.
    stride = max(1, len(samples) // 2048)
    for index in range(0, len(samples), stride):
        if not math.isfinite(float(samples[index])):
            raise RuntimeError(f"{label}: generated non-finite audio sample at {index}")

    print(
        f"PASS {label}: generated {len(samples)} samples at {sample_rate} Hz "
        f"({len(samples) / sample_rate:.2f} seconds)"
    )


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: smoke_test_models.py PROJECT_DIR", file=sys.stderr)
        return 2

    project = Path(sys.argv[1]).resolve()
    assets = project / "app" / "src" / "main" / "assets" / "models"
    espeak = assets / "espeak-ng-data"
    kareem_dir = assets / "kareem"
    nabra_dir = assets / "nabra"

    required = [
        espeak / "phondata",
        espeak / "phontab",
        espeak / "phonindex",
        kareem_dir / "ar_JO-kareem-medium.onnx",
        kareem_dir / "tokens.txt",
        nabra_dir / "model.int4.onnx",
        nabra_dir / "tokens.txt",
        nabra_dir / "voices.bin",
    ]
    missing = [str(path) for path in required if not path.is_file() or path.stat().st_size == 0]
    if missing:
        raise FileNotFoundError("Missing/empty model files:\n" + "\n".join(missing))

    print(f"Sherpa-ONNX Python version: {getattr(sherpa_onnx, '__version__', 'unknown')}")

    # Kareem: Arabic Jordanian Piper VITS, one speaker, 22.05 kHz.
    kareem = sherpa_onnx.OfflineTts(
        sherpa_onnx.OfflineTtsConfig(
            model=sherpa_onnx.OfflineTtsModelConfig(
                vits=sherpa_onnx.OfflineTtsVitsModelConfig(
                    model=str(kareem_dir / "ar_JO-kareem-medium.onnx"),
                    tokens=str(kareem_dir / "tokens.txt"),
                    data_dir=str(espeak),
                ),
                num_threads=2,
                provider="cpu",
            ),
        )
    )
    verify_audio("Kareem / VITS", kareem, 22050)
    del kareem
    gc.collect()

    # Nabra: Arabic MSA Kokoro, speaker af_msa (sid 0), 24 kHz.
    nabra = sherpa_onnx.OfflineTts(
        sherpa_onnx.OfflineTtsConfig(
            model=sherpa_onnx.OfflineTtsModelConfig(
                kokoro=sherpa_onnx.OfflineTtsKokoroModelConfig(
                    model=str(nabra_dir / "model.int4.onnx"),
                    voices=str(nabra_dir / "voices.bin"),
                    tokens=str(nabra_dir / "tokens.txt"),
                    data_dir=str(espeak),
                ),
                num_threads=2,
                provider="cpu",
            ),
        )
    )
    verify_audio("Nabra / Kokoro", nabra, 24000)
    del nabra
    gc.collect()

    print("PASS: both Arabic models completed CPU speech generation.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
