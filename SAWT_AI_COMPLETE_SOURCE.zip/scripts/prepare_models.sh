#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-.}"
PROJECT_DIR="$(cd "$PROJECT_DIR" && pwd)"
APP_DIR="$PROJECT_DIR/app"
ASSETS="$APP_DIR/src/main/assets/models"
WORK="${RUNNER_TEMP:-/tmp}/sawt-ai-model-setup"

mkdir -p "$APP_DIR/libs" "$ASSETS/kareem" "$ASSETS/nabra" "$WORK" "$APP_DIR/src/main/assets"

fetch() {
  local url="$1" out="$2"
  if [[ ! -s "$out" ]]; then
    echo "Downloading: $(basename "$out")"
    rm -f "$out.part"
    curl --fail --location --retry 5 --retry-all-errors --connect-timeout 30 \
      --output "$out.part" "$url"
    test -s "$out.part"
    mv "$out.part" "$out"
  fi
}

# Sherpa-ONNX 1.13.8 Android AAR; SHA-256 verified against the SourceForge release mirror.
AAR="$APP_DIR/libs/sherpa-onnx.aar"
fetch "https://sourceforge.net/projects/sherpa-onnx.mirror/files/v1.13.8/sherpa-onnx-static-link-onnxruntime-1.13.8.aar/download" "$AAR"
printf '%s  %s\n' \
  'b22c3fc1b6a45666d28892bb2f7694beeb77a8362d7ebd77c1a5431ec9435471' "$AAR" | sha256sum --check -
unzip -t "$AAR" >/dev/null
AAR_CONTENTS="$WORK/sherpa-aar-contents.txt"
unzip -Z1 "$AAR" > "$AAR_CONTENTS"
grep -Eq '^jni/arm64-v8a/.*sherpa-onnx-jni.*\.so$' "$AAR_CONTENTS"
grep -Eq '^jni/armeabi-v7a/.*sherpa-onnx-jni.*\.so$' "$AAR_CONTENTS"

# Kareem: Arabic Jordanian Piper VITS model.
KAREEM_TAR="$WORK/kareem.tar.bz2"
fetch "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ar_JO-kareem-medium.tar.bz2" "$KAREEM_TAR"
rm -rf "$WORK/kareem-unpacked"
mkdir -p "$WORK/kareem-unpacked"
tar -xjf "$KAREEM_TAR" -C "$WORK/kareem-unpacked"
KAREEM_MODEL="$(find "$WORK/kareem-unpacked" -type f -name 'ar_JO-kareem-medium.onnx' -print -quit)"
KAREEM_TOKENS="$(find "$WORK/kareem-unpacked" -type f -name 'tokens.txt' -print -quit)"
test -n "$KAREEM_MODEL"
test -n "$KAREEM_TOKENS"
test "$(stat -c%s "$KAREEM_MODEL")" -gt 40000000
cp "$KAREEM_MODEL" "$ASSETS/kareem/ar_JO-kareem-medium.onnx"
cp "$KAREEM_TOKENS" "$ASSETS/kareem/tokens.txt"

# Shared eSpeak NG phoneme data used by both offline Arabic models.
ESPEAK_TAR="$WORK/espeak-ng-data.tar.bz2"
fetch "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/espeak-ng-data.tar.bz2" "$ESPEAK_TAR"
rm -rf "$WORK/espeak-unpacked" "$ASSETS/espeak-ng-data"
mkdir -p "$WORK/espeak-unpacked"
tar -xjf "$ESPEAK_TAR" -C "$WORK/espeak-unpacked"
ESPEAK_DIR="$(find "$WORK/espeak-unpacked" -type d -name 'espeak-ng-data' -print -quit)"
test -n "$ESPEAK_DIR"
for required in phondata phontab phonindex; do
  test -s "$ESPEAK_DIR/$required"
done
cp -a "$ESPEAK_DIR" "$ASSETS/espeak-ng-data"

# Nabra-82M: Apache-2.0 Arabic MSA Kokoro model. The model card documents
# model.int4.onnx + tokens.txt + voices.bin, with speaker id 0.
NABRA_BASE="https://huggingface.co/marwanelamami/nabra-82m-sherpa-onnx/resolve/main"
fetch "$NABRA_BASE/model.int4.onnx" "$ASSETS/nabra/model.int4.onnx"
fetch "$NABRA_BASE/tokens.txt" "$ASSETS/nabra/tokens.txt"
fetch "$NABRA_BASE/voices.bin" "$ASSETS/nabra/voices.bin"
test "$(stat -c%s "$ASSETS/nabra/model.int4.onnx")" -gt 50000000
test "$(stat -c%s "$ASSETS/nabra/tokens.txt")" -gt 100
test "$(stat -c%s "$ASSETS/nabra/voices.bin")" -gt 100000

# Final completeness checks: prevent accidentally packaging missing or HTML error files.
test -s "$ASSETS/kareem/ar_JO-kareem-medium.onnx"
test -s "$ASSETS/kareem/tokens.txt"
test -s "$ASSETS/nabra/model.int4.onnx"
test -s "$ASSETS/nabra/tokens.txt"
test -s "$ASSETS/nabra/voices.bin"
for required in phondata phontab phonindex; do
  test -s "$ASSETS/espeak-ng-data/$required"
done
cp "$PROJECT_DIR/THIRD_PARTY_NOTICES.md" "$APP_DIR/src/main/assets/THIRD_PARTY_NOTICES.txt"

echo "SAWT AI offline runtime and both voice models are ready."
du -sh "$APP_DIR/libs/sherpa-onnx.aar" "$ASSETS"
